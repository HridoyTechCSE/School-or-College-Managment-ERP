<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LeavePurpose extends Model
{
    //
}
