<?php

namespace App\Model\Employee;

use Illuminate\Database\Eloquent\Model;

class EmployeeSalaryLog extends Model
{
    //
}
